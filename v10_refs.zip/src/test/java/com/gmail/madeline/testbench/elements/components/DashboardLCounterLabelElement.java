package com.gmail.madeline.testbench.elements.components;

import com.vaadin.testbench.TestBenchElement;
import com.vaadin.testbench.elementsbase.Element;

@Element("dashboard-counter-label")
public class DashboardLCounterLabelElement extends TestBenchElement {

}
