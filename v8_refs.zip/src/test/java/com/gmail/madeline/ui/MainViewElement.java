package com.gmail.madeline.ui;

public class MainViewElement extends MainViewDesignElement {

}