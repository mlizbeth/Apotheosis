package com.gmail.madeline.ui.views.admin.product;

public class ProductAdminViewElement extends ProductAdminViewDesignElement implements CrudViewElement {

}