package com.gmail.madeline.ui.views.admin.user;

import com.gmail.madeline.ui.views.admin.product.CrudViewElement;

public class UserAdminViewElement extends UserAdminViewDesignElement implements CrudViewElement {

}